```dataview
TABLE authors AS "Author", source AS "Source"
FROM "recipes"
SORT authors DESC
WHERE authors
```