```dataview
TABLE source AS "Source", authors AS "Author"
FROM "recipes"
SORT source DESC
WHERE source
```